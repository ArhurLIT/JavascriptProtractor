const SIGIN_PAGE_TITLE = 'Sign in to GitHub · GitHub'
const CANT_FIND_EMAIL = 'Can\'t find that email, sorry.'
const CANT = 'Can\'t'
const INCORRECT_CREDENTIALS = 'Incorrect username or password.'
const SIGUP_PAGE_TITLE = 'Join GitHub · GitHub'
const SIGUP_PAGE_HEADER = 'Create your personal account'
const EXISTING_EMAIL = 'm.ie'
const NEW_EMAIL = 'randomsample4t53@gmail.com'

module.exports = {
	SIGIN_PAGE_TITLE: SIGIN_PAGE_TITLE, 
	CANT_FIND_EMAIL: CANT_FIND_EMAIL,
	CANT: CANT,
	INCORRECT_CREDENTIALS: INCORRECT_CREDENTIALS,
	SIGUP_PAGE_TITLE: SIGUP_PAGE_TITLE,
	SIGUP_PAGE_HEADER: SIGUP_PAGE_HEADER,
	EXISTING_EMAIL: EXISTING_EMAIL,
	NEW_EMAIL: NEW_EMAIL,
}